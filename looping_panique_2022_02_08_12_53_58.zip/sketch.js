function setup() {
  createCanvas(600, 400);
}

function draw(){
  background(100,200,100);
  
  strokeWeight(10);
  stroke(255);
  
  var x = 0;
  
  while (x <= width){
    fill(0,255,100);
  ellipse(x, 300 ,70 ,25);
  x = x + 50;     
 }
  
     for(varx = 0; x < + width; x = x + 50)  {
       fill(200,100,100);
        ellipse(x, 300 ,25 ,25);
       
     }              
}